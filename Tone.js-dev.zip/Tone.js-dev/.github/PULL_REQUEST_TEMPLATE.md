1. Please make all pull requests on the `dev` branch.
2. Don't commit build files
2. Try to get all [tests](https://github.com/Tonejs/Tone.js/wiki/Testing) to pass.


